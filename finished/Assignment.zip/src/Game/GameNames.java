package Game;

/**
 * Interfesz, a jatekbeli konstansok deifnialasara.
 */
public interface GameNames {
    int EMPTY = ' ';
    int PLAYER1 = 'X';
    int PLAYER2 = 'O';
}
