package Menu;

/**
 * Interfesz, a menubeli konstansok definialasara.
 */
public interface MenuNames {
    int MAIN = 0;
    int INIT = 1;
    int LOAD = 2;
    int GAME = 3;
    int EXIT = -1;
}
